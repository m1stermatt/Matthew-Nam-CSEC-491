# Clear memory

rm(list = ls())
gc()

library(reshape)
library(gridExtra)
library(ggplot2)
library(RColorBrewer)

read_data = function() {
	get_data_from = function() {
		df_ttc <- read.csv("Data/mas-tc/15m-tc.txt", header = TRUE, sep = "")
		df_eq <- read.csv("Data/mas-tc/15m-tc-equil.txt", header = TRUE, sep = "")
		df_conv <- read.csv("Data/mas-tc/15m-tc-conv.txt", header = TRUE, sep = "")
		df_ttc <- subset(df_ttc, select=c("Experiment", "ItPerfMeas", "alpha1", "alpha2", "beta1", "beta2", "delta", "numConv", "avgTTC", "seTTC", "medTTC"))
		df_conv <- subset(df_conv, select=c("Experiment", "avgPrGain", "sePrGain"))
		
		ret <- merge(df_ttc, df_eq, by="Experiment")
		ret <- merge(ret, df_conv, by="Experiment")
		return(ret)
	}
	
	df <- get_data_from()
	
	df$alpha1 <- as.factor(df$alpha1)
	df$beta1 <- as.factor(df$beta1 / 25000)
	df$conv <- df$numConv / 1000
	df$ope <- df$numSessions_2 / df$numConv
	df$spne <- df$numSessions_3 / 1000
	df$avgTTC <- df$avgTTC * 25000
	df$seTTC <- df$seTTC * 25000
	return(df)
}

# Load data
df <- read_data()

cc <- scales::seq_gradient_pal("lightblue", "blue", "Lab")(seq(0,1,length.out=10))

p1 <- ggplot(df, aes(x = ItPerfMeas, y = seTTC)) +
	geom_line(aes(color = beta1)) +
	geom_point(color="black", size=0.4) +
	scale_colour_manual(values=cc, name="Beta", guide = guide_legend(reverse = TRUE)) +
	xlab(bquote(t[c])) +
	ylab(expression("t\'"["c"])) +
	ylim(0, 5*10^6) + 
	ggtitle(label = "Average Time To Convergence, m=15") +
	theme_bw() +
	theme(axis.title.y = element_text(angle=0, vjust = 0.5), legend.position = "none")

p2 <- ggplot(df, aes(x = ItPerfMeas, y = ope)) +
	geom_line(aes(color = beta1)) +
	geom_point(color="black", size=0.2) +
	scale_colour_manual(values=cc, name="Beta", guide = guide_legend(reverse = TRUE)) +
	xlab(bquote(t[c])) +
	ylab(label = "% OPE Outcome") +
	ggtitle(label = "% OPE Convergence, m=15") +
	ylim(c(0,1)) +
	theme_bw() +
	theme(strip.placement = "outside",
							plot.title = element_text(hjust = 0.5),
							strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))

# png(paste0("15m-tc.png"), units="in", width=16, height=6, res=300)
grid.arrange(p1, p2, ncol=2)
# dev.off()

# png(paste0("15m-tc-std.png"), units="in", width=16, height=6, res=300)
# ggplot(df[df$beta1==8*10^(-6),], aes(x = ItPerfMeas, y = avgTTC)) +
# 	geom_line(aes(color = beta1)) +
# 	geom_point(color="black", size=0.2) +
# 	geom_errorbar(aes(ymin = avgTTC-seTTC, ymax=avgTTC+seTTC, color=beta1, alpha=0.4),
# 															width=.5, position=position_dodge(0.05),) +
# 	scale_colour_manual(values=cc, name="Beta", guide = guide_legend(reverse = TRUE)) +
# 	xlab(bquote(t[c])) +
# 	ylab(expression("t\'"["c"])) +
# 	ylim(0, 5*10^6) + 
# 	ggtitle(label = "Average Time To Convergence, m=15, Beta=8e-06") +
# 	theme_bw() +
# 	theme(axis.title.y = element_text(angle=0, vjust = 0.5), legend.position = "none")
# dev.off()
