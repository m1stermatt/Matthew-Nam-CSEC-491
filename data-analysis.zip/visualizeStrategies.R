# Clear memory

rm(list = ls())
gc()

# Set working directory and load packages

# Info experiment is formatted by
## Session number
## Converged switch
## Number of episodes to convergence
## Limit path cycle length
## States in limit path cycle
## Prices selected in limit path cycle
## Profits from limit path cycle
## - Strategies

library(reshape)
library(ggplot2)
library(RColorBrewer)

readSessionInfo = function(con, num_actions) {
	get_next_line = function() {
		return(trimws(readLines(con, n = 1)))
	}
	i_session <- as.integer(get_next_line())
	converged <- as.logical(as.integer(get_next_line()))
	time_to_convergence <- as.double(get_next_line())
	cycle_length <- as.integer(get_next_line())
	visited_states <- as.integer(strsplit(get_next_line(), "\\s+")[[1]])
	p_hist <- as.integer(strsplit(get_next_line(), "\\s+")[[1]])
	visited_profits <- as.double(strsplit(get_next_line(), "\\s+")[[1]])
	a1 <- c()
	a2 <- c()
	for (i in 1:num_actions**2) {
		price_pair = as.integer(strsplit(get_next_line(), "\\s+")[[1]])
		a1 <- append(a1, price_pair[1])
		a2 <- append(a2, price_pair[2])
	}
	get_next_line()
	if (converged==FALSE) {
		print("wow")
	}
	return(list("a1"=a1, "a2"=a2, "visited_states"=visited_states, "converged"=converged, "time_to_convergence"=time_to_convergence))
}

readInfoExperiment = function(filename, num_actions) {
	con <- file(filename, "r")
	states <- apply(expand.grid(1:num_actions, 1:num_actions), 1, function(row) paste0(row["Var2"], ",", row["Var1"]))
	res_a1 <- setNames(data.frame(matrix(ncol=num_actions**2, nrow=0)), states)
	res_a2 <- setNames(data.frame(matrix(ncol=num_actions**2, nrow=0)), states)
	visited_states <- list()
	converged <- setNames(data.frame(matrix(ncol = 2, nrow = 0)), c("converged", "ttc"))
	for (i in 1:1000) {
		strat <- readSessionInfo(con, num_actions)
		res_a1[nrow(res_a1) + 1,] <- strat[["a1"]]
		res_a2[nrow(res_a2) + 1,] <- strat[["a2"]]
		visited_states[[i]] <- strat[["visited_states"]]
		converged[nrow(converged) + 1] <- c(strat[["converged"]], strat[["time_to_convergence"]])
	}
	return(list("a1"=res_a1, "a2"=res_a2, "visited_states"=visited_states, "converged"=converged))
}

rowToStrategy = function(strat, num_actions) {
	res <- matrix(strat, nrow=num_actions, byrow=TRUE)
	return(res)
}

visualizeStrategy = function(strat1, strat2, num_actions, individual, session_num, cycle) {
	makeRects <- function(coord,border){
		cAbove = expand.grid(1:num_actions,1:num_actions)[coord, ]
		xl=cAbove[,1]-0.49
		yb=cAbove[,2]-0.49
		xr=cAbove[,1]+0.49
		yt=cAbove[,2]+0.49
		rect(xl,yb,xr,yt,border=border,lwd=3)
	}
	
	p_labels <- paste0("p", seq(1:num_actions))
	data1 <- expand.grid(a2=p_labels, a1=p_labels)
	data1$resp <- strat1[1,]
	data1$agent <- "Agent 1"
	data2 <- expand.grid(a2=p_labels, a1=p_labels)
	data2$resp <- strat2[1,]
	data2$agent <- "Agent 2"
	data <- rbind(data1, data2)
	
	if (missing(individual)) {
		return(ggplot(data, aes(a1, a2, fill=resp)) + 
			facet_grid(~ agent) +
			geom_tile() +
			scale_fill_gradient(name="Price Response", low="aliceblue", high="cornflowerblue") + 
			xlab(label = "Agent 1 Price") + 
			ylab(label = "Agent 2 Price") + 
			ggtitle(label = paste0("Average Limit Strategies for m=", num_actions)) +
			theme_bw() +
			theme(strip.placement = "outside",
									plot.title = element_text(hjust = 0.5),
									strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF")))
	} else {
		return(ggplot(data, aes(a1, a2, fill=factor(resp, levels=c(1:num_actions)))) + 
			facet_grid(~ agent) +
			geom_tile() + 
			geom_tile(data = data[c(cycle, cycle + num_actions**2),], fill = NA, color = "black", size = 1) +
			scale_fill_manual(name="Price Response", values=scales::seq_gradient_pal("aliceblue", "cornflowerblue", "Lab")(seq(0,1,length.out=num_actions))) +  
			xlab(label = "Agent 1 Price") + 
			ylab(label = "Agent 2 Price") + 
			ggtitle(label = paste0("Limit Strategies for m=", num_actions, ", i=", session_num)) +
			theme_bw() +
			theme(strip.placement = "outside",
									plot.title = element_text(hjust = 0.5),
									strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF")))
	}
}

# Load data
m = 50
sessionStrategies <- readRDS(paste0(m,"m-Experiments.rds"))
# sessionStrategies <- readInfoExperiment(paste0("Data/ExpResults (5-62)/InfoExperiment_", sprintf("%02d",m-4), ".txt"), m)
a1 <- sessionStrategies[["a1"]]
a2 <- sessionStrategies[["a2"]]
visited_states <- sessionStrategies[["visited_states"]]
converged <- sessionStrategies[["converged"]]

# cycle_lengths <- c(1:max(lengths(visited_states)))
# cycle_counts <- lapply(cycle_lengths, FUN=function(len) sum(lengths(visited_states) == len))
# cycle_indices <- lapply(cycle_lengths, FUN=function(len) which(lengths(visited_states) == len))
# cycle_length = 1
# visualizeStrategy(t(as.matrix(colMeans(a1[cycle_indices[[cycle_length]],]))), t(as.matrix(colMeans(a2[cycle_indices[[cycle_length]],]))), m)

pNPos <- 1/12 * m + 1
pMPos <- m - 1/12 * m


# plot_list = list()
# for (i in 1:100) {
# 	session_num <- i
# 	plot1 <- visualizeStrategy(as.matrix(a1[session_num,]), as.matrix(a2[session_num,]), m, true, session_num, visited_states[[session_num]])
# 	my.lines<-data.frame(x=c(0.5,pNPos, 0.5, pMPos), y=c(pNPos,0.5,pMPos,0.5),
# 																						xend=c(m+0.5,pNPos,m+0.5,pMPos), yend=c(pNPos,m+0.5,pMPos,m+0.5))
# 	plot2 <- plot1 + geom_segment(data=my.lines, aes(x,y,xend=xend, yend=yend), size=0.2, inherit.aes=F, color="red")
# 	plot_list[[i]] <- plot2
# }
# 
# pdf("plots.pdf", width=12, height=6)
# for (i in 1:100) {
# 	print(plot_list[[i]])
# }
# dev.off()



png(paste0(m, "m-strategy-avg.png"), units="in", width=12, height=6, res=300)
plot1 <- visualizeStrategy(t(as.matrix(colMeans(a1))), t(as.matrix(colMeans(a2))), m)
my.lines<-data.frame(x=c(0.5,pNPos, 0.5, pMPos), y=c(pNPos,0.5,pMPos,0.5),
																					xend=c(m+0.5,pNPos,m+0.5,pMPos), yend=c(pNPos,m+0.5,pMPos,m+0.5))
plot1 + geom_segment(data=my.lines, aes(x,y,xend=xend, yend=yend), size=0.2, inherit.aes=F, color="red")
dev.off()

# png(paste0(m, "m-strategy-sd.png"), units="in", width=12, height=6, res=300)
# visualizeStrategy(t(as.matrix(sapply(a1, sd))), t(as.matrix(sapply(a2, sd))), m)
# dev.off()

# saveRDS(sessionStrategies, file="40m-Experiments.rds")

