# Clear memory

rm(list = ls())
gc()

# Set working directory and load packages

library(reshape)
library(ggplot2)
library(RColorBrewer)

visualizeCycles = function(num_actions, cycle) {
	p_labels <- paste0("p", seq(1:num_actions))
	df <- expand.grid(a2=p_labels, a1=p_labels)
	df$count <- 0
	for (i in 1:1000) {
		iCycle <- cycle[[i]]
		for (state in iCycle) {
			df[state, "count"] = df[state, "count"] + 1
		}
	}
	
	df$count <- df$count / 1000
	
	return(ggplot(df, aes(a1, a2, fill=count)) +
									geom_tile() +
									scale_fill_gradient(name="Count", low="white", high="cornflowerblue") +
									xlab(label = "Agent 1 Price") +
									ylab(label = "Agent 2 Price") +
									ggtitle(label = "Probability of States in Cycle") +
									theme_bw() +
									theme(strip.placement = "outside",
															plot.title = element_text(hjust = 0.5),
															strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF")))
}

# Load data
m = 40
sessionStrategies <- readRDS(paste0(m,"m-Experiments.rds"))
a1 <- sessionStrategies[["a1"]]
a2 <- sessionStrategies[["a2"]]
visited_states <- sessionStrategies[["visited_states"]]

pNPos <- 1/12 * m + 1
pMPos <- m - 1/12 * m

png(paste0(m, "m-cycles.png"), units="in", width=7, height=6, res=300)
plot1 <- visualizeCycles(m, visited_states)
my.lines<-data.frame(x=c(0.5,pNPos, 0.5, pMPos), y=c(pNPos,0.5,pMPos,0.5), 
																					xend=c(m+0.5,pNPos,m+0.5,pMPos), yend=c(pNPos,m+0.5,pMPos,m+0.5))
plot1 + geom_segment(data=my.lines, aes(x,y,xend=xend, yend=yend), size=0.2, inherit.aes=F, color="red")
dev.off()

