# Clear memory

rm(list = ls())
gc()

# Set working directory and load packages

# Info experiment is formatted by
## Session number
## Converged switch
## Number of episodes to convergence
## Limit path cycle length
## States in limit path cycle
## Prices selected in limit path cycle
## Profits from limit path cycle
## - Strategies

library(reshape)
library(ggplot2)
library(RColorBrewer)


# Load data
m = 15
df <- read.csv(paste0("Data/single-agent/", m, "m.txt"), header = TRUE, sep = "")
df$beta1 <- as.factor(df$beta1)
df$numConv <- df$numConv/1000

cc <- scales::seq_gradient_pal("lightblue", "blue", "Lab")(seq(0,1,length.out=10))

png(paste0(m, "m-sessions_converged.png"), units="in", width=10, height=5, res=300)
ggplot(df, aes(x = ItPerfMeas, y = numConv)) +
	geom_line(aes(color = beta1)) +
	scale_colour_manual(values=cc, name="Epsilon", guide = guide_legend(reverse = TRUE)) +
	xlab(bquote(t[c])) +
	ylab(label = "% Sessions Converged") +
	ggtitle(label = paste("Single-Agent Convergence, m=",m)) +
	ylim(c(0,1)) +
	theme_bw()
dev.off()

# png("sessions_converged.png", units="in", width=10, height=5, res=300)
# ggplot(df, aes(EpPerfMeas, beta1, fill=numConv)) + 
# 	geom_tile() +
# 	scale_fill_gradient(name="% Sessions Converged", low="white", high="cornflowerblue") + 
# 	xlab(label = "Episodes for Convergence") + 
# 	ylab(label = "Epsilon") + 
# 	ggtitle(label = "Single-Agent Convergence") +
# 	theme_bw() +
# 	theme(strip.placement = "outside",
# 							plot.title = element_text(hjust = 0.5),
# 							strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))
# dev.off()

png(paste0(m, "m-time_to_converge.png"), units="in", width=10, height=5, res=300)
ggplot(df, aes(x = ItPerfMeas, y = avgTTC*25000)) + 
	geom_line(aes(color = beta1)) +
	scale_colour_manual(values=cc, name="Epsilon", guide = guide_legend(reverse = TRUE)) +
	xlab(bquote(t[c])) +
	ylab(expression("t\'"["c"])) +
	ggtitle(label = paste0("Average Time To Convergence, m=", m)) +
	theme_bw() +
	theme(axis.title.y = element_text(angle=0, vjust = 0.5))
dev.off()

# png("time_to_converge.png", units="in", width=10, height=5, res=300)
# 	ggplot(df, aes(EpPerfMeas, beta1, fill=avgTTC)) + 
# 	geom_tile() +
# 	scale_fill_gradient(name="Time to Convergence", low="white", high="cornflowerblue") + 
# 	xlab(label = "Episodes for Convergence") + 
# 	ylab(label = "Epsilon") + 
# 		ggtitle(label = "Average Time To Convergence") +
# 	theme_bw() +
# 	theme(strip.placement = "outside",
# 							plot.title = element_text(hjust = 0.5),
# 							strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))
# 	dev.off()





