# Clear memory

rm(list = ls())
gc()

library(reshape)
library(gridExtra)
library(ggplot2)
library(RColorBrewer)

# Load data
m = 10
df1 <- read.csv(paste0("Data/single-agent/", m, "m.txt"), header = TRUE, sep = "")
df2 <- read.csv(paste0("Data/single-agent/", m, "m-equil.txt"), header = TRUE, sep = "")
df <- merge(df1, df2, by="Experiment")
df$beta1 <- as.factor(df$beta1)
df$ope <- df$numSessions_2 / df$numSessions_1
df$spne <- df$numSessions_3 / df$numSessions_1

df <- subset(df, select=c("Experiment", "ope", "spne", "ItPerfMeas", "beta1"))
df <- melt(df, na.rm = FALSE, id = c("Experiment", "ItPerfMeas", "beta1"))

equil.labs <- c("OPE", "SPNE")
names(equil.labs) <- c("ope", "spne")

cc <- scales::seq_gradient_pal("lightblue", "blue", "Lab")(seq(0,1,length.out=10))

png(paste0(m, "m-equil-converged.png"), units="in", width=14, height=6, res=300)
ggplot(df, aes(x = ItPerfMeas, y = value)) + 
	facet_wrap(~variable, labeller = labeller(variable = equil.labs)) +
	geom_line(aes(color = beta1)) +
	scale_colour_manual(values=cc, name="Epsilon", guide = guide_legend(reverse = TRUE)) +
	xlab(bquote(t[c])) +
	ylab(label = "% Outcome") +
	ggtitle(label = paste0("% Equilibrium Convergence, m=",m)) +
	ylim(c(0,1)) +
	theme_bw() +
	theme(strip.placement = "outside",
							plot.title = element_text(hjust = 0.5),
							strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))
dev.off()

# png(paste0(m, "m-ope_converged.png"), units="in", width=10, height=5, res=300)
# plot1 <- ggplot(df, aes(x = ItPerfMeas, y = ope)) + 
# 	geom_line(aes(color = beta1)) +
# 	scale_colour_manual(values=cc, name="Epsilon", guide = guide_legend(reverse = TRUE)) +
# 	xlab(bquote(t[c])) +
# 	ylab(label = "% OPE Convergence") +
# 	ggtitle(label = paste0("% OPE Convergence, m=",m)) +
# 	ylim(c(0,1)) +
#  theme_bw() 
# dev.off()

# png(paste0(m, "m-spne_converged.png"), units="in", width=10, height=5, res=300)
# plot2 <- ggplot(df, aes(x = ItPerfMeas, y = spne)) + 
# 	geom_line(aes(color = beta1)) +
# 	scale_colour_manual(values=cc, name="Epsilon", guide = guide_legend(reverse = TRUE)) +
# 	xlab(bquote(t[c])) +
# 	ylab(label = paste0("% SPNE Convergence, m=",m)) +
# 	ggtitle(label = "% SPNE Convergence") +
# 	ylim(c(0,1)) +
# 	theme_bw() 
# dev.off()