# Clear memory

rm(list = ls())
gc()

library(reshape)
library(ggplot2)
library(RColorBrewer)

get_m_exp_data = function(m) {
	df1 <- read.csv(paste0("Data/single-agent/", m, "m.txt"), header = TRUE, sep = "")
	df2 <- read.csv(paste0("Data/single-agent/", m, "m-equil.txt"), header = TRUE, sep = "")
	df <- merge(df1, df2, by="Experiment")
	df$beta1 <- as.factor(df$beta1)
	df$ope <- df$numSessions_2 / df$numSessions_1
	df$m <- m
	
	df <- subset(df, select=c("Experiment", "ope", "ItPerfMeas", "beta1", "m"))
	
	return(df)
}

# Load data
df_2m <- get_m_exp_data(2)
df_3m <- get_m_exp_data(3)
df_5m <- get_m_exp_data(5)

df <- melt(rbind(df_2m, df_3m, df_5m), na.rm = FALSE, id = c("Experiment", "ItPerfMeas", "beta1", "ope"))

m.labs <- c("m=2", "m=3", "m=5")
names(m.labs) <- c("2", "3", "5")

cc <- scales::seq_gradient_pal("lightblue", "blue", "Lab")(seq(0,1,length.out=10))

png("m2,3,5-equil.png", units="in", width=14, height=6, res=300)
ggplot(df, aes(x = ItPerfMeas, y = ope)) +
	facet_wrap(~value, labeller = labeller(value=m.labs)) +
	geom_line(aes(color = beta1)) +
	scale_colour_manual(values=cc, name="Epsilon", guide = guide_legend(reverse = TRUE)) +
	xlab(bquote(t[c])) +
	ylab(label = "% OPE Outcomes") +
	ggtitle(label = "Single-Agent OPE Convergence, m=2,3,5") +
	ylim(c(0,1)) +
	theme_bw() +
	theme(strip.placement = "outside",
							plot.title = element_text(hjust = 0.5),
							strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))
dev.off()
