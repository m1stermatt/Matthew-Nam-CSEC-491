# Clear memory

rm(list = ls())
gc()

library(reshape)
library(gridExtra)
library(ggplot2)
library(RColorBrewer)
library(xtable)

# Load data
m = 3
df1 <- read.csv(paste0("Data/single-agent/", m, "m.txt"), header = TRUE, sep = "")
df2 <- read.csv(paste0("Data/single-agent/", m, "m-equil.txt"), header = TRUE, sep = "")
df <- merge(df1, df2, by="Experiment")
df$epsilon <- as.factor(df$beta1)
df$avgTTC <- df$avgTTC * 25000
df$total <- df$avgTTC + df$ItPerfMeas
df$ope <- df$numSessions_2 / df$numSessions_1

df <- subset(df, select=c("Experiment", "ope", "ItPerfMeas", "avgTTC", "total", "epsilon"))

epsilons <- unique(df$epsilon)
rows <- list()
i <- 0
for (epsilon in epsilons) {
	i <- i + 1
	df_ep <- df[df$epsilon == epsilon,]
	rows[[i]] <- df_ep[which.max(df_ep$ope),c("ope", "ItPerfMeas", "avgTTC", "total")]
	# print(epsilon)
	# print(rows[[i]])
	print(formatC(as.matrix(rows[[i]]), format = "e", digits = 1))
}

# formatC(rows, format = "e", digits = 2)




