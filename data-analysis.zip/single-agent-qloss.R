# Clear memory

rm(list = ls())
gc()

library(reshape)
library(gridExtra)
library(ggplot2)
library(RColorBrewer)

# Load data
m = 10
df1 <- read.csv(paste0("Data/single-agent/", m, "m.txt"), header = TRUE, sep = "")
df2 <- read.csv(paste0("Data/single-agent/", m, "m-qg.txt"), header = TRUE, sep = "")

df <- merge(df1, df2, by="Experiment")
df$beta1.x <- as.factor(df$beta1.x)

df <- subset(df, select=c("Experiment", "QGapNotBRAllStAg1", "ItPerfMeas", "beta1.x"))

cc <- scales::seq_gradient_pal("lightblue", "blue", "Lab")(seq(0,1,length.out=10))

png(paste0(m, "m-qloss.png"), units="in", width=12, height=6, res=300)
ggplot(df, aes(x = ItPerfMeas, y = QGapNotBRAllStAg1)) +
	geom_line(aes(color = beta1.x)) +
	scale_colour_manual(values=cc, name="Epsilon", guide = guide_legend(reverse = TRUE)) +
	xlab(bquote(t[c])) +
	ylab(label = "Q-loss") +
	ggtitle(label = paste0("Q-Loss, m=",m)) +
	theme_bw() +
	theme(strip.placement = "outside",
							plot.title = element_text(hjust = 0.5),
							strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))
dev.off()
