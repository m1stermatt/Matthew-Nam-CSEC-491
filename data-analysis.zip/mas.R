# Clear memory

rm(list = ls())
gc()

library(reshape)
library(gridExtra)
library(ggplot2)
library(RColorBrewer)

read_data = function(count, label) {
	
	get_next_line = function(con) {
		return(trimws(readLines(con, n = 1)))
	}
	
	get_reg_data = function(filename) {
		con <- file(filename, "r")
		df <- setNames(data.frame(matrix(ncol=10, nrow=0)), c("Experiment", "alpha1", "alpha2", "beta1", "beta2", "delta", "numConv", "avgTTC", "seTTC", "medTTC"))
		get_next_line(con) # Read header
		while ( TRUE ) {
			row <- get_next_line(con)
			if (length(row) == 0) {
				break
			}
			row <- strsplit(row, " +")[[1]]
			df[nrow(df) + 1,] <- as.double(c(row[1:6], tail(row, 4)))
		}
		close(con)
		return(df)
	}
	
	get_conv_data = function(filename, currExp) {
		con <- file(filename, "r")
		df <- setNames(data.frame(matrix(ncol=3, nrow=0)), c("Experiment", "avgPrGain", "sePrGain"))
		get_next_line(con) # Read header
		while ( TRUE ) {
			row <- get_next_line(con)
			if (length(row) == 0) {
				break
			}
			row <- strsplit(row, " +")[[1]]
			expNum <- as.integer(row[1])
			m <- 5 + (expNum + currExp - 1) %% 46
			row_length <- length(row)
			end <- row_length - m ^ 2 # this is where the price data begins which is variable line to line
			df[nrow(df) + 1,] <- as.double(c(expNum, row[(end-1):end]))
		}
		close(con)
		return(df)
	}
	
	get_data_from = function(index, currExp) {
		df_ttc <- get_reg_data(paste0("Data/mas/", label, "-", index, ".txt"))
		df_eq <- read.csv(paste0("Data/mas/", label, "-equil-", index, ".txt"), header = TRUE, sep = "")
		df_conv <- get_conv_data(paste0("Data/mas/", label, "-conv-", index, ".txt"), currExp)
		
		ret <- merge(df_ttc, df_eq, by="Experiment")
		ret <- merge(ret, df_conv, by="Experiment")
		return(ret)
	}
	
	df <- get_data_from(1, 0)
	for (i in 2:count) {
		new_df <- get_data_from(i, nrow(df))
		new_df$Experiment <- new_df$Experiment + nrow(df)
		df <- rbind(df, new_df)
	}
	df$m <- 5 + (df$Experiment - 1) %% 46
	df$alpha1 <- as.factor(df$alpha1)
	df$beta1 <- as.factor(df$beta1)
	df$conv <- df$numConv / 1000
	df$ope <- df$numSessions_2 / df$numConv
	df$spne <- df$numSessions_3 / 1000
	df$avgTTC <- df$avgTTC * 25000
	return(df)
}

plot_data = function(info, title, y_name, df) {
	col <- info[1]
	title_type <- info[2]
	col_name <- info[3]
	percent <- info[4]
	if (percent) {
		# png(paste0("-", col, ".png"), units="in", width=16, height=6, res=300)
		ggplot(df, aes(m, beta1, fill=get(col))) +
			geom_tile() +
			scale_fill_gradient(name=col_name, low="aliceblue", high="cornflowerblue", limit=c(0,1)) +
			xlab(label = "m") +
			ylab(label = y_name) +
			ggtitle(label = paste0(title, " ", title_type)) +
			theme_bw() +
			theme(strip.placement = "outside",
									strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))
		# dev.off()
	} else {
		# png(paste0("-", col, ".png"), units="in", width=16, height=6, res=300)
		ggplot(df, aes(m, beta1, fill=get(col))) +
			geom_tile() +
			scale_fill_gradient(name=col_name, low="aliceblue", high="cornflowerblue") +
			xlab(label = "m") +
			ylab(label = y_name) +
			ggtitle(label = paste0(title, " ", title_type)) +
			theme_bw() +
			theme(strip.placement = "outside",
									strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))
		# dev.off()
	}
}

# Load data
data_types <- list()
data_types[[1]] <- c("da-de", 3, "Decaying Learning, Decaying Exploration", "Beta")
data_types[[2]] <- c("ca-de", 2, "Constant Learning, Decaying Exploration", "Beta")
data_types[[3]] <- c("da-ce", 5, "Decaying Learning, Constant Exploration", "Epsilon")

data_type_index <- 3
label <- data_types[[data_type_index]][1]
num_files <- data_types[[data_type_index]][2]
title <- data_types[[data_type_index]][3]
y_name <- data_types[[data_type_index]][4]
df <- read_data(num_files, label)

graph_types <- list()
graph_types[["avgGain"]] <- c("avgPrGain", "Average Profit Gain", "Δ", TRUE)
graph_types[["avgGain_conv"]] <- c("avgPrGain_1", "Average Profit Gain (Converged Sessions)", "Δ", TRUE)
graph_types[["avgGain_ope"]] <- c("avgPrGain_2", "Average Profit Gain (OPE Sessions)", "Δ", TRUE)
graph_types[["avgTTC"]] <- c("avgTTC", "Average Time to Convergence", "Num Periods", FALSE)
graph_types[["numConv"]] <- c("conv", "Convergence", "%", TRUE)
graph_types[["numOPE"]] <- c("ope", "OPE Convergence", "%", TRUE)


plot_data(graph_types[["numConv"]], title, y_name, df)

