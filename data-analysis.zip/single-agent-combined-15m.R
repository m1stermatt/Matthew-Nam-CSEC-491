# Clear memory

rm(list = ls())
gc()

library(reshape)
library(gridExtra)
library(ggplot2)
library(RColorBrewer)

read_data = function(count) {
	get_data_from = function(currIndex) {
		df_ttc <- read.csv(paste0("Data/single-agent/15m/15m-", currIndex, ".txt"), header = TRUE, sep = "")
		df_eq <- read.csv(paste0("Data/single-agent/15m/15m-equil-", currIndex, ".txt"), header = TRUE, sep = "")
		df_ttc <- subset(df_ttc, select=c("Experiment", "ItPerfMeas", "alpha1", "alpha2", "beta1", "beta2", "delta", "numConv", "avgTTC", "seTTC", "medTTC"))
		
		ret <- merge(df_ttc, df_eq, by="Experiment")
		return(ret)
	}
	
	df <- get_data_from(1)
	
	for (i in 2:count) {
		new_df <- get_data_from(i)
		df <- rbind(df, new_df)
	}
	
	df$alpha1 <- as.factor(df$alpha1)
	df$beta1 <- as.factor(df$beta1)
	df$conv <- df$numConv / 1000
	df$ope <- df$numSessions_2 / df$numConv
	df$spne <- df$numSessions_3 / 1000
	df$avgTTC <- df$avgTTC * 25000
	df$seTTC <- df$seTTC * 25000
	df$m <- 15
	return(df)
}

# Load data
df <- read_data(4)
cc <- scales::seq_gradient_pal("lightblue", "blue", "Lab")(seq(0,1,length.out=10))

p1 <- ggplot(df, aes(x = ItPerfMeas, y = avgTTC)) +
	geom_line(aes(color = beta1)) +
	scale_colour_manual(values=cc, name="Epsilon", guide = guide_legend(reverse = TRUE)) +
	xlab(bquote(t[c])) +
	ylab(expression("t\'"["c"])) +
	ggtitle(label = paste0("Average Time To Convergence, m=15")) +
	theme_bw() +
	theme(axis.title.y = element_text(angle=0, vjust = 0.5), legend.position = "none")

p2 <- ggplot(df, aes(x = ItPerfMeas, y = ope)) + 
	geom_line(aes(color = beta1)) +
	scale_colour_manual(values=cc, name="Epsilon", guide = guide_legend(reverse = TRUE)) +
	xlab(bquote(t[c])) +
	ylab(label = "% OPE Outcome") +
	ggtitle(label = paste0("% OPE Convergence, m=15")) +
	ylim(c(0,1)) +
	theme_bw() +
	theme(strip.placement = "outside",
							plot.title = element_text(hjust = 0.5),
							strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))

png(paste0("15m-single-agent.png"), units="in", width=16, height=6, res=300)
grid.arrange(p1, p2, ncol=2)
dev.off()

