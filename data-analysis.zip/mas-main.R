# Clear memory

rm(list = ls())
gc()

library(reshape)
library(gridExtra)
library(ggplot2)
library(RColorBrewer)

read_data = function(m) {
	get_data_from = function(m) {
		df_ttc <- read.csv(paste0("Data/mas-2/", m, "m.txt"), header = TRUE, sep = "")
		df_eq <- read.csv(paste0("Data/mas-2/", m, "m-equil.txt"), header = TRUE, sep = "")
		df_conv <- read.csv(paste0("Data/mas-2/", m, "m-conv.txt"), header = TRUE, sep = "")
		df_ttc <- subset(df_ttc, select=c("Experiment", "alpha1", "alpha2", "beta1", "beta2", "delta", "numConv", "avgTTC", "seTTC", "medTTC"))
		df_conv <- subset(df_conv, select=c("Experiment", "avgPrGain", "sePrGain"))
		
		ret <- merge(df_ttc, df_eq, by="Experiment")
		ret <- merge(ret, df_conv, by="Experiment")
		return(ret)
	}
	
	df <- get_data_from(m)
	
	df$alpha1 <- as.factor(df$alpha1)
	df$beta1 <- as.factor(df$beta1)
	df$conv <- df$numConv / 1000
	df$ope <- df$numSessions_2 / df$numConv
	df$spne <- df$numSessions_3 / 1000
	df$avgTTC <- df$avgTTC * 25000
	df$m <- as.factor(m)
	return(df)
}

plot_data = function(info, df) {
	col <- info[1]
	title_type <- info[2]
	col_name <- info[3]
	percent <- info[4]
	if (percent) {
		# png(paste0("-", col, ".png"), units="in", width=16, height=6, res=300)
		ggplot(df, aes(ItPerfMeas, beta1, fill=get(col))) +
			geom_tile() +
			scale_fill_gradient(name=col_name, low="aliceblue", high="cornflowerblue", limit=c(0,1)) +
			xlab(label = "t_c") +
			ylab(label = "Beta") +
			ggtitle(label = title_type) +
			theme_bw() +
			theme(strip.placement = "outside",
									strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))
		# dev.off()
	} else {
		# png(paste0("-", col, ".png"), units="in", width=16, height=6, res=300)
		ggplot(df, aes(ItPerfMeas, beta1, fill=get(col))) +
			geom_tile() +
			scale_fill_gradient(name=col_name, low="aliceblue", high="cornflowerblue") +
			xlab(label = "t_c") +
			ylab(label = "Beta") +
			ggtitle(label = title_type) +
			theme_bw() +
			theme(strip.placement = "outside",
									strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))
		# dev.off()
	}
}

# Load data
df <- rbind(read_data(2), read_data(3), read_data(5), read_data(10), read_data(15))
# df <- rbind(read_data(2), read_data(3), read_data(5))

# graph_types <- list()
# graph_types[["avgGain"]] <- c("avgPrGain", "Average Profit Gain", "Δ", TRUE)
# graph_types[["avgGain_conv"]] <- c("avgPrGain_1", "Average Profit Gain (Converged Sessions)", "Δ", TRUE)
# graph_types[["avgGain_ope"]] <- c("avgPrGain_2", "Average Profit Gain (OPE Sessions)", "Δ", TRUE)
# graph_types[["avgTTC"]] <- c("avgTTC", "Average Time to Convergence", "Num Periods", FALSE)
# graph_types[["numConv"]] <- c("conv", "Convergence", "%", TRUE)
# graph_types[["numOPE"]] <- c("ope", "OPE Convergence", "%", TRUE)
# 
# 

ggplot(df, aes(m, beta1, fill=avgTTC)) +
	geom_tile() +
	scale_fill_gradient(name="wow", low="white", high="cornflowerblue") +
	xlab(label = "m") +
	ylab(label = "Beta") +
	ggtitle(label = "title_type") +
	theme_bw() +
	theme(strip.placement = "outside",
							strip.background = element_rect(fill = "#EEEEEE", color = "#FFFFFF"))

# cc <- scales::seq_gradient_pal("lightblue", "blue", "Lab")(seq(0,1,length.out=10))
# 
# ggplot(df, aes(x = beta1, y = ope)) +
# 		geom_line(aes(color = m)) +
# 		geom_point(color="black", size=0.2) +
# 		geom_errorbar(aes(ymin = avgTTC-seTTC, ymax=avgTTC+seTTC, color=beta1, alpha=0.4),
# 																width=.5, position=position_dodge(0.05),) +
# 		scale_colour_manual(values=cc, name="Beta", guide = guide_legend(reverse = TRUE)) +
# 		xlab(bquote(t[c])) +
# 		ylab(expression("t\'"["c"])) +
# 		ylim(0, 5*10^6) +
# 		ggtitle(label = "Average Time To Convergence, m=15, Beta=8e-06") +
# 		theme_bw() +
# 		theme(axis.title.y = element_text(angle=0, vjust = 0.5), legend.position = "none")
# 
